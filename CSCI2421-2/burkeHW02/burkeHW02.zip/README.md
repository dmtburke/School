# burkeHW02

Dalton Burke, CSCI 2421 HW 02

This program implements a "Set" class based on the "ArrayBag" class. Implemented the union operation as "+" operator, and the asymmetric difference operation as "-" operator. Reads in two sets from file "setInput.txt" and displays the two sets, their union, and both differences.

Status: Functioning fully.

Written, compiled and tested on Gentoo GNU/Linux with GCC 4.9.3
